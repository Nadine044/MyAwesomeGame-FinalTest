My Awesome Game!!

Paint background sprite and character sprite.
Play audio and fx.
Move sprite around the window using keyboard.

Nadine Gutiérrez.